﻿namespace MauiApp2;

public partial class MainPage : ContentPage
{
    public MainPage()
	{
		InitializeComponent();
	}

    private void SwapImages(object sender, EventArgs e)
    {
        var temp = Cake1.Source;
        Cake1.Source = Cake2.Source;
        Cake2.Source = temp;
    }

    private void OnTextChanged(object sender, EventArgs e)
    {
        SearchBar searchBar = (SearchBar)sender;
        ShowSearchBarText.Text = searchBar.Text;
    }
}

