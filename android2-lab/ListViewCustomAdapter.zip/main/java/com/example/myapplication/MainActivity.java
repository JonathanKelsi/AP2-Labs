package com.example.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    List<Post> posts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView lstFeed = (ListView) findViewById(R.id.lstFeed);

        posts = generatePosts();
        final FeedAdapter feedAdapter = new FeedAdapter(posts);
        lstFeed.setAdapter(feedAdapter);
        lstFeed.setOnItemClickListener((parent, view, position, id) -> {
            Post p = posts.get(position);
            p.select();
            feedAdapter.notifyDataSetChanged();
        });
    }

    private List<Post> generatePosts() {
        List<Post> posts = new ArrayList<>();

        posts.add(new Post("Hemi", "10:01", 0, 0));
        posts.add(new Post("Hemi2", "10:02", 0, 0));
        posts.add(new Post("Hemi3", "10:03", 0, 0));
        posts.add(new Post("Hemi4", "10:04", 0, 0));

        return posts;
    }
}