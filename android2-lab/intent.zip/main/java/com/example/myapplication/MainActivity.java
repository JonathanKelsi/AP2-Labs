package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn = findViewById(R.id.btnUpdate);
        btn.setOnClickListener(view -> {
            EditText edName = findViewById(R.id.etName);

            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(edName.getText().toString()));
            startActivity(intent);
        });
    }
}