namespace Hello;

public partial class MainWindow : ContentPage
{
	public MainWindow()
	{
		InitializeComponent();
	}
}