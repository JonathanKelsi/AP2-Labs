﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Hello
{
    public class MyCommand : ICommand
    {
        public delegate void Operation(object parameter);

        private Operation operation;

        public MyCommand(Operation operation)
        {
            this.operation = operation;
        }

        bool ICommand.CanExecute(object parameter)
        {
            return true;
        }

        void ICommand.Execute(object parameter)
        {
            if (operation != null)
            {
                operation(parameter);
            }
        }

        public event EventHandler CanExecuteChanged = (_, _) => { };
    }
}
