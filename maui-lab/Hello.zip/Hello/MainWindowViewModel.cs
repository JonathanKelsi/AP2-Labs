﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hello
{
    public class MainWindowViewModel
    {
        private ObservableCollection<string> foo = new() { "Foo",
                                                           "Bar",
                                                           "Baz" };
        public ObservableCollection<string> Foo
        {
            get { return foo; }
            set
            {
                foo = value;
            }
        }
        public MyCommand AddCommand => new(item => Foo.Add((string)item));
    }
}
